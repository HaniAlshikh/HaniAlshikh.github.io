# H-S Videos (plugin.video.hs)

Watch from a huge selection of Arabic Videos reliably and ad-free... 

Please Note: This addon requires the use of a compatible cloud service.
		
## Acknowledgments

This plugin is based on [Seren - Modular Multi-source Addon](https://github.com/nixgates/plugin.video.seren)

## License

see [LICENSE](LICENSE.md)